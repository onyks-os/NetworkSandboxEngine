"""Core engine sub-package."""
